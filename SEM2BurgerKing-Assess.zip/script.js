// Creating threepicsContainer to hold three sections
var threepicsContainer = document.createElement("div");
document.body.appendChild(threepicsContainer);

// Creating threepics1 section
var threepics1 = document.createElement("div");
var threepics1image = document.createElement("img");
threepics1image.src = "pic.png";

threepics1.appendChild(threepics1image);

// Creating threepics1 text content
var threepics1textContainer = document.createElement("div");
var threepics1text = document.createElement("p");
threepics1text.textContent = "YourBurgerKing";
var threepics1desc = document.createElement("p");
threepics1desc.textContent = "Earn points and get rewarded with every order on the BK App.";
threepics1textContainer.appendChild(threepics1text);
threepics1textContainer.appendChild(threepics1desc);
threepics1.appendChild(threepics1textContainer);

// Styling for threepics1
threepics1.style.width = "700px";
threepics1textContainer.style.backgroundColor = "white";
threepics1textContainer.style.position = "relative";
threepics1textContainer.style.bottom = "15px";
threepics1textContainer.style.padding = "8px 23px";
threepics1textContainer.style.borderRadius = "10px";
threepics1textContainer.style.borderTopLeftRadius = "0px";
threepics1textContainer.style.borderTopRightRadius = "0px";
threepics1text.style.color = "#502314";
threepics1desc.style.color = "#502314";
threepics1image.style.width = "560px";
threepics1image.style.height = "284px";
threepics1.style.width = "560px";
// Creating threepics2 section
var threepics2 = document.createElement("div");
var threepics2image = document.createElement("img");
threepics2image.src = "pic1.png";
threepics2image.style.width = "560px";
threepics2image.style.height = "305px";
threepics2.appendChild(threepics2image);

// Creating threepics2 text content
var threepics2textContainer = document.createElement("div");
var threepics2text = document.createElement("p");
threepics2text.textContent = "BK® Delivers, powered by Deliveroo®";
var threepics2desc = document.createElement("p");
threepics2desc.textContent = "Get your flame-grilled favourites straight to your door today!.";
threepics2textContainer.appendChild(threepics2text);
threepics2textContainer.appendChild(threepics2desc);
threepics2.appendChild(threepics2textContainer);

// Styling for threepics2
threepics2.style.width = "700px";
threepics2textContainer.style.backgroundColor = "white";
threepics2textContainer.style.position = "relative";
threepics2textContainer.style.bottom = "15px";
threepics2textContainer.style.padding = "8px 23px";
threepics2textContainer.style.borderRadius = "10px";
threepics2textContainer.style.borderTopLeftRadius = "0px";
threepics2textContainer.style.borderTopRightRadius = "0px";
threepics2text.style.color = "#502314";
threepics2desc.style.color = "#502314";
threepics2image.style.width = "560px";
threepics2image.style.height = "284px";
threepics2.style.width = "560px";

// Creating threepics3 section
var threepics3 = document.createElement("div");
var threepics3image = document.createElement("img");
threepics3image.src = "pic2.png";
threepics3image.style.width = "560px";
threepics3image.style.height = "284px";
threepics3image.style.margin;
threepics3.appendChild(threepics3image);

// Create threepics3 text content
var threepics3textContainer = document.createElement("div");
var threepics3text = document.createElement("p");
threepics3text.textContent = "Peppercorn Gourmet Kings";
var threepics3desc = document.createElement("p");
threepics3desc.textContent = "150g of Aberdeen Angus or Crispy Chicken with a classic Peppercorn mayo.";
threepics3textContainer.appendChild(threepics3text);
threepics3textContainer.appendChild(threepics3desc);
threepics3.appendChild(threepics3textContainer);

// Styling for threepics3
threepics3.style.width = "700px";
threepics3textContainer.style.backgroundColor = "white";
threepics3textContainer.style.position = "relative";
threepics3textContainer.style.bottom = "15px";
threepics3textContainer.style.padding = "8px 22px";
threepics3textContainer.style.borderRadius = "10px";
threepics3textContainer.style.borderTopLeftRadius = "0px";
threepics3textContainer.style.borderTopRightRadius = "0px";
threepics3text.style.color = "#502314";
threepics3desc.style.color = "#502314";
threepics3image.style.width = "560px";
threepics3image.style.height = "284px";
threepics3.style.width = "560px";


threepicsContainer.appendChild(threepics1);
threepicsContainer.appendChild(threepics2);
threepicsContainer.appendChild(threepics3);

// Styling for threepicsContainer
threepicsContainer.style.display = "grid";
threepicsContainer.style.gridTemplateColumns = "repeat(2, 1fr)";
threepicsContainer.style.gridGap = "15px";
threepicsContainer.style.width = "calc(560px * 2 + 15px";
threepicsContainer.style.margin = "auto";
threepicsContainer.style.marginTop = "100px";

// Adding a button to threepics1
var threepics1button = document.createElement("button");
threepics1button.textContent = "Get Rewarded";
threepics1button.className = "button";
threepics1button.style.position = "relative";
threepics1button.style.bottom = "103px"; 
threepics1button.style.left = "400px";  
threepics1button.style.padding = "13px 25px";
threepics1button.style.borderRadius = "55px";
threepics1button.style.borderColor = "red";
threepics1button.style.backgroundColor = "white";
threepics1button.style.color = "red";
threepics1button.style.fontSize = "17px";

threepics1.appendChild(threepics1button);

// Adding a button to threepics2
var threepics2button = document.createElement("button");
threepics2button.textContent = "Order Now";
threepics2button.className = "button";
threepics2button.style.position = "relative";
threepics2button.style.bottom = "103px"; 
threepics2button.style.left = "420px";  
threepics2button.style.padding = "13px 25px";
threepics2button.style.borderRadius = "25px";
threepics2button.style.borderColor = "transparent";
threepics2button.style.backgroundColor = "red";
threepics2button.style.color = "white";
threepics2button.style.fontSize = "17px";
threepics2.appendChild(threepics2button);
// Adding a button to threepics3
var threepics3button = document.createElement("button");
threepics3button.textContent = "Discover the range";
threepics3button.className = "button";
threepics3button.style.position = "relative";
threepics3button.style.bottom = "123px"; 
threepics3button.style.left = "360px";  
threepics3button.style.padding = "13px 25px";
threepics3button.style.borderRadius = "25px";
threepics3button.style.backgroundColor = "red";
threepics3button.style.borderColor = "transparent";
threepics3button.style.color = "white";
threepics3button.style.fontSize = "17px";
threepics3.appendChild(threepics3button);


window.onscroll = function() {
    var navbar = document.getElementById("navbar1");
    var sticky = navbar.offsetTop;

    if (window.pageYOffset > sticky) {
        navbar.classList.add("sticky");
    } else {
        navbar.classList.remove("sticky");
    }
};

//first footer
var firstFooter = document.createElement("div");
firstFooter.style.backgroundColor = "#f2e1c9";
firstFooter.style.padding = "130px";
firstFooter.style.textAlign = "center";
firstFooter.style.marginTop = "250px";
firstFooter.style.marginBottom = "-50px";
firstFooter.style.overflow = "hidden";

//Second footer
var secondFooter = document.createElement("div");
secondFooter.className = "second-footer";
secondFooter.style.backgroundColor = "#2b0200";
secondFooter.style.padding = "300px";
secondFooter.style.textAlign = "center";
secondFooter.style.overflow = "hidden";


var footer = document.createElement("footer");
footer.appendChild(firstFooter);
footer.appendChild(secondFooter);

document.body.appendChild(footer);


// Creating an image element
var imageElement = document.createElement("img");
// Settting image source and alt attributes
imageElement.src = "https://cdn.sanity.io/images/czqk28jt/prod_bk_gb/ec025695dc78c9198b572d6b0aadda878415b78c-1340x2014.png?w=750&q=40&fit=max&auto=format";
imageElement.alt = "phoneimg";
imageElement.width = 450;
imageElement.height = 650;
imageElement.style.position = "relative";
imageElement.style.bottom = "1550px";
// imageElement.style.marginTop = "50px";
imageElement.classList.add("moving-image");
// Appending the image to the second footer
firstFooter.appendChild(imageElement);
document.body.appendChild(imageElement);

firstFooter.innerHTML = "<p id='p10'>Save £££ <br>With offers on <br>demand.</p>";

const newParagraph = document.createElement('p');
newParagraph.innerHTML = '    Apple and the Apple logo are trademarks of Apple Inc., registered in the U.S.<br>and other countries.App Store is a service mark of Apple Inc. Google Play is a<br> trademark of Google Inc. Terms apply.'; // Set the text content with line breaks
//styling for the new paragraph
newParagraph.style.position = 'absolute'; 
newParagraph.style.top = '235%'; 
newParagraph.style.right = '4%';
newParagraph.style.color = '#502314'; 
newParagraph.style.fontSize = '15px'; 
newParagraph.style.fontFamily = "Flame Sans";
newParagraph.style.textAlign = "left";
firstFooter.appendChild(newParagraph);

var AppimgElement = document.createElement("img");

// image source and alt attributes
AppimgElement.src = "app.png";
AppimgElement.alt = "2imgs";
AppimgElement.width = 110;
AppimgElement.height = 50;
AppimgElement.style.position = "relative";
AppimgElement.style.left = "600px";
AppimgElement.style.bottom = "1700px";

AppimgElement.classList.add("img");
// Append the image to the first footer
firstFooter.appendChild(AppimgElement);
document.body.appendChild(AppimgElement);

var GoogleimgElement = document.createElement("img");

//image source and alt attributes
GoogleimgElement.src = "google.png";
GoogleimgElement.alt = "2imgs";
GoogleimgElement.width = 120;
GoogleimgElement.height = 50;
GoogleimgElement.style.position = "relative";
GoogleimgElement.style.left = "650px";
GoogleimgElement.style.bottom = "1700px";

GoogleimgElement.classList.add("img");
// Append the image to the first footer
firstFooter.appendChild(GoogleimgElement);
document.body.appendChild(GoogleimgElement);

const newPar = document.createElement('p');
newPar.innerHTML =  "<p >BK® INFO </p>";

//styling for the new paragraph
newPar.style.position = 'absolute'; 
newPar.style.top = '270%'; 
newPar.style.right = '85%';
newPar.style.color = '#f2e1c9'; 
newPar.style.fontSize = '30px'; 
newPar.style.fontFamily = "Flame Sans";
secondFooter.appendChild(newPar);

const newPar2 = document.createElement('p');
newPar2.innerHTML =  "<p >BK® AND YOU </p>";

//styling for the new paragraph
newPar2.style.position = 'absolute'; 
newPar2.style.top = '270%'; 
newPar2.style.right = '40%';
newPar2.style.color = '#f2e1c9'; 
newPar2.style.fontSize = '30px'; 
newPar2.style.fontFamily = "Flame Sans";
secondFooter.appendChild(newPar2);

// Creating an unordered list element
var ul = document.createElement("ul");

// Creating an array of link texts and URLs
var links = [
    { text: "About BK ®", url: "https://www.burgerking.co.uk/about-bk" },
    { text: "FAQs", url: "https://www.burgerking.co.uk/faqs" },
    { text: "Policies", url: "https://www.burgerking.co.uk/corp-policies" },
    { text: "Get in touch", url: "https://www.burgerking.co.uk/get-in-touch" },
    { text: "Terms & Conditions", url: "https://www.burgerking.co.uk/terms-of-use" },
    { text: "Guest Trac", url: "https://www.bk-feedback-uk.com/" },
    { text: "Trademarks", url: "https://www.burgerking.co.uk/trademarks" }
];
links.forEach(function(link) {
    var li = document.createElement("li");
    var a = document.createElement("a");
    a.textContent = link.text; 
    a.href = link.url; 
a.style.color = "#f6e1c9"
a.style.textDecoration = "none";
a.style.textAlign = "left";
a.style.position = "relative";
a.style.right = "610px";
a.style.bottom = "80px";
a.style.fontFamily = "Flames Sans";
a.style.listStyleType = "none";

    li.appendChild(a);
    // Appending the list item element to the unordered list element
    ul.appendChild(li);
});
// Appending the unordered list element to an existing element in the HTML document
secondFooter.appendChild(ul);

var seclinks = [
  { text: "Careers", url: "https://www.burgerking.co.uk/careers" },
  { text: "Privacy Policies", url: "https://www.burgerking.co.uk/privacy-policy" },
  { text: "Modern Slavery Statement", url: "https://www.burgerking.co.uk/modern-statement" },
  { text: "Tax Strategy", url: "https://www.burgerking.co.uk/tax-strategy" },

];
seclinks.forEach(function(link) {
  var li = document.createElement("li");
  var a = document.createElement("a");
  a.textContent = link.text; 
  a.href = link.url; 
a.style.color = "#f6e1c9"
a.style.textDecoration = "none";
a.style.textAlign = "left";
a.style.position = "relative";
a.style.right = "5px";
a.style.top = "-220px";  
a.style.fontFamily = "Flames Sans";

  li.appendChild(a);
  // Appending the list item element to the unordered list element
  ul.appendChild(li);
});
// Appending the unordered list element to an existing element in the HTML document
secondFooter.appendChild(ul);

const line1 = document.createElement('hr');
line1.style.borderTop = '1px'; // Set the border top to create a thin line
line1.style.margin = '5px 50px'; 
line1.style.position = 'relative';
line1.style.top = '-40px';
line1.style.right = '220px';
line1.style.width = '1300px';

secondFooter.appendChild(line1);

var footerimg1Element = document.createElement("img");
// Setting image source and alt attributes
footerimg1Element.src = "footerimg1.png";
  footerimg1Element.alt = "fimg";
  footerimg1Element.width = 1300;
  footerimg1Element.height = 35;
  footerimg1Element.style.position = "relative";
  footerimg1Element.style.left = "130px";
  footerimg1Element.style.bottom = "1000px";
secondFooter.appendChild(footerimg1Element);
document.body.appendChild(footerimg1Element);


const newPar3 = document.createElement('p');
newPar3.innerHTML = "<p>TM & Copyright 2021 Burger King Corporation. All Rights Reserved.</p>";
//styling for the new paragraph
newPar3.style.color = '#f6e1c9'; 
newPar3.style.fontSize = '12px'; 
newPar3.style.fontFamily = "Flame";
newPar3.style.position = 'relative'; 
newPar3.style.right = '450px'; 
newPar3.style.top = '55px'; 

secondFooter.appendChild(newPar3);
// Creating the second line
const line2 = document.createElement('hr');
line2.style.borderTop = '1px'; 
line2.style.position = 'relative';
line2.style.margin = '10px 50px'; 
line2.style.top = '100px';
line2.style.right = '220px';
line2.style.width = '1300px';

secondFooter.appendChild(line2);
