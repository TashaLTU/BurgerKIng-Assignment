
// Create an image element
var image = document.createElement("img");
image.src = "pic.png"; 
image.alt = "Image";
image.width = 550;
image.height = 309;
image.style.marginLeft="203px";
image.style.marginBottom="150px";
image.style.marginTop="50px";
image.style.float = "left"; // Move the image to the left
document.getElementById("image-container").appendChild(image);

var image1 = document.createElement("img");
image1.src = "pic1.png"; 
image1.alt = "Image";
image1.width = 550;
image1.height = 309;
image1.style.marginRight="203px";
image1.style.marginBottom="150px";
image1.style.marginTop="50px";
image1.style.float = "right"; // Move the image to the right
document.getElementById("image-container").appendChild(image1);


var image2 = document.createElement("img");
image2.src = "pic2.png"; 
image2.alt = "Image";
image2.width = 550;
image2.height = 309;
image2.style.marginLeft="203px";
image2.style.position= "relative";
image2.style.bottom="50px";
image2.style.float = "left"; // Move the image to the right
document.getElementById("image-container").appendChild(image2);




window.onscroll = function() {
    var navbar = document.getElementById("navbar1");
    var sticky = navbar.offsetTop;

    if (window.pageYOffset > sticky) {
        navbar.classList.add("sticky");
    } else {
        navbar.classList.remove("sticky");
    }
};


var firstFooter = document.createElement("div");
firstFooter.style.backgroundColor = "#f2e1c9";
firstFooter.style.padding = "250px";
firstFooter.style.textAlign = "center";
firstFooter.style.marginTop = "990px";
firstFooter.style.marginBottom = "-50px";

var secondFooter = document.createElement("div");
secondFooter.className = "second-footer";
secondFooter.style.backgroundColor = "#2c130c";
secondFooter.style.padding = "300px";
secondFooter.style.textAlign = "center";

var footer = document.createElement("footer");
footer.appendChild(firstFooter);
footer.appendChild(secondFooter);

document.body.appendChild(footer);


// Create an image element
var imageElement = document.createElement("img");

// Set image source and alt attributes
imageElement.src = "https://cdn.sanity.io/images/czqk28jt/prod_bk_gb/ec025695dc78c9198b572d6b0aadda878415b78c-1340x2014.png?w=750&q=40&fit=max&auto=format";
imageElement.alt = "phoneimg";
imageElement.width = 450;
imageElement.height = 650;
// imageElement.style.marginTop = "50px";

imageElement.classList.add("moving-image");
// Append the image to the second footer
firstFooter.appendChild(imageElement);
document.body.appendChild(imageElement);


const p1 = document.createElement("p1")
p1.innerHTML = "YourBurgerKing";
document.body.appendChild(p1);
p1.style.position = "relative";
p1.style.right = "-208px";
p1.style.bottom = "1760px";
p1.style.backgroundColor = "white";
p1.style.color = "#502314";
p1.style.paddingTop = "20px";
p1.style.paddingBottom = "60px";
p1.style.paddingLeft = "5px";
p1.style.paddingRight = "400px";
p1.style.borderRadius = "10px";
p1.style.borderTopLeftRadius = "0px";
p1.style.borderTopRightRadius = "0px";
p1.style.fontFamily = "Flame Sans";
p1.style.fontWeight = "bold";
p1.style.fontSize = "19px";

const p2 = document.createElement("p1")
p2.innerHTML = "BK® Delivers, powered by Deliveroo®";
document.body.appendChild(p2);
p2.style.position = "relative";
p2.style.left = "242px";
p2.style.bottom = "1760px";
p2.style.backgroundColor = "white";
p2.style.color = "#502314";
p2.style.paddingTop = "20px";
p2.style.paddingBottom = "60px";
p2.style.paddingLeft = "4px";
p2.style.paddingRight = "227px";
p2.style.borderRadius = "10px";
p2.style.borderTopLeftRadius = "0px";
p2.style.borderTopRightRadius = "0px";
p2.style.fontFamily = "Flame Sans";
p2.style.fontWeight = "bold";
p2.style.fontSize = "19px";


// const s3 = document.createElement("section");
// const x3 = document.createElement("p");
// x3.innerHTML = "YourBurgerKing";
// s3.appendChild(x3);
// s3.style.height = "100px";
// s3.style.backgroundColor = "white";
// s3.style.width = "300px";
// s3.style.position = "relative";
// s3.style.bottom= "150px";
// //s3.style.top = "0px";
// s3.style.right = "10px";
// s3.style.left = "10px";
// document.body.appendChild(s3);


// const t3 = document.createElement("p3");
// t3.innerHTML = "Peppercorn Gourmet Kings";
// document.body.appendChild(t3);
// t3.style.position = "relative";
// t3.style.right = "882px";
// t3.style.bottom = "1350px";
// t3.style.backgroundColor = "white";
// t3.style.color = "#502314";
// t3.style.paddingTop = "20px";
// t3.style.paddingBottom = "60px";
// t3.style.paddingLeft = "80px";
// t3.style.paddingRight = "150px";
// t3.style.borderRadius = "10px";
// t3.style.borderTopLeftRadius = "0px";
// t3.style.borderTopRightRadius = "0px";
// t3.style.fontFamily = "Flame Sans";
// t3.style.fontWeight = "bold";
// t3.style.fontSize = "19px";
// t3.style.marginBottom = "-10px";
// t3.style.width = "300px";

// Set the text content of the firstFooter
firstFooter.textContent = "This is the updated text within the first footer.";
// To append text and keep the existing content, you can use the following:
firstFooter.textContent += " Appended text.";
// To insert HTML content into the firstFooter:
firstFooter.innerHTML = "<p>Save £££ With offers on demand.</p>";

// Create a section element
//const sectionElement = document.createElement("section");

// // Set the content of the section element
// sectionElement.textContent = "This is a new section.";

// // Set styles for the section element
// sectionElement.style.backgroundColor = "#f2f2f2";
// sectionElement.style.padding = "50px";
// sectionElement.style.marginTop = "20px";

// // Append the section element to the body of the document
// document.body.appendChild(sectionElement);